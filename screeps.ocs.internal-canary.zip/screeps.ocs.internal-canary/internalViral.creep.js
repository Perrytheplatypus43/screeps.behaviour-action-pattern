const mod = {};
module.exports = mod;
mod.compileBody = function (room, params, sort = true) {
    const moveRatio = 1 - (_.isNumber(params.moveRatio) ? params.moveRatio : 0.5);
    const parts = this.baseOf.internalViral.compileBody.apply(this, [room, params, sort]);
    const attackCount = _.sum(parts, p=> p===ATTACK);
    const rangedCount = _.sum(parts, p=> p===RANGED_ATTACK);
    const moveCount = _.sum(parts, p=> p===MOVE);
    if (moveCount * 2 >= parts.length && attackCount >= rangedCount) {
        // relocate move parts as armor so that 2:1 move when hits === hullHits
        const movedMoves = parts.splice(_.findIndex(parts, p=> p===MOVE), Math.floor(moveRatio * moveCount));
        const insertIndex = Math.max(0, _.findIndex(parts, p=> !Population.stats.creep.armorParts[p]));
        parts.splice(insertIndex, 0, ...movedMoves);
    }
    return parts;
};
